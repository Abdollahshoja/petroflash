"""Interactive feed input with optional PR1976 feed-property diagnostics."""

import argparse

from .conditions import TPConditions
from .database import ComponentDatabase
from .mixture import Mixture
from .pr_fugacity import mixture_pr_log_fugacity
from .pr_mixing import mixture_pr_parameters, zero_kij
from .pr_roots import solve_pr_roots
from .stability import search_pr_stability
from .flash import flash_tp


def read_mixture(database):
    """Read user choices and return a validated Mixture."""
    print("\nAvailable components:")
    for name in database.names():
        component = database.get(name)
        print(f"  {component.name} | CAS: {component.cas_number}")

    while True:
        text = input(
            "\nEnter component names or CAS numbers, separated by commas: "
        )
        identifiers = [item.strip() for item in text.split(",")]
        try:
            components = database.select(identifiers)
        except (TypeError, ValueError, KeyError) as error:
            print(f"Selection error: {error}")
            continue
        break

    while True:
        percentages = []
        for component in components:
            while True:
                text = input(f"Mole percent of {component.name}: ")
                try:
                    value = float(text)
                except ValueError:
                    print("Enter a number, using a decimal point if needed.")
                    continue
                if not 0 <= value <= 100:
                    print("Enter a finite percentage between 0 and 100.")
                    continue
                percentages.append(value)
                break
        try:
            return Mixture(components, percentages)
        except ValueError as error:
            print(f"Composition error: {error}")
            print("Enter all percentages again; their sum must be 100.")


def read_conditions():
    """Read explicit units and positive absolute TP conditions."""
    while True:
        unit = input("Temperature unit [K/C]: ").strip().upper()
        if unit not in ("K", "C"):
            print("Choose K or C.")
            continue
        try:
            value = float(input(f"Temperature [{unit}]: "))
            temperature = TPConditions.from_units(
                value, 1, temperature_unit=unit, pressure_unit="Pa"
            ).temperature_k
        except ValueError as error:
            print(f"Temperature error: {error}")
            continue
        break

    print("Pressure must be ABSOLUTE, not gauge pressure.")
    while True:
        unit = input("Absolute pressure unit [Pa/bar]: ").strip().lower()
        if unit not in ("pa", "bar"):
            print("Choose Pa or bar; gauge units are not accepted.")
            continue
        try:
            value = float(input(f"Absolute pressure [{unit}]: "))
            return TPConditions.from_units(
                temperature, value, temperature_unit="K", pressure_unit=unit
            )
        except ValueError as error:
            print(f"Pressure error: {error}")


def confirm_zero_kij():
    """Require explicit consent to a model assumption for this run."""
    print("\nPR1976 feed-property calculation.")
    print("No binary interaction dataset is supplied in this mode.")
    while True:
        choice = input("Use the assumption that ALL kij = 0? [yes/no]: ").strip().casefold()
        if choice in ("yes", "y"):
            return True
        if choice in ("no", "n"):
            return False
        print("Choose yes or no.")


def print_pr_feed(mixture, conditions, *, kij):
    """Evaluate each admissible feed root, without selecting an equilibrium phase."""
    parameters = mixture_pr_parameters(mixture, conditions, kij=kij)
    roots = solve_pr_roots(A=parameters.A, B=parameters.B)
    # Compute every result before displaying a successful calculation.
    results = tuple(mixture_pr_log_fugacity(mixture, conditions, kij=kij, z=z)
                    for z in roots.admissible_roots)
    print("\nPR1976 properties at the OVERALL FEED composition:")
    print(f"a_m = {parameters.a_m:.12g} Pa m^6/mol^2")
    print(f"b_m = {parameters.b_m:.12g} m^3/mol")
    print(f"A = {parameters.A:.12g}; B = {parameters.B:.12g}")
    print("Distinct real roots:", roots.real_roots)
    print("Roots satisfying Z>B:", roots.admissible_roots)
    print("Scaled polynomial residuals:", roots.scaled_residuals)
    for result in results:
        print(f"\nZ = {result.z:.12g}")
        print(f"{'Component':<20} {'ln(phi)':>16}")
        for component, value in zip(mixture.components, result.ln_phi):
            print(f"{component.name:<20} {value:>16.10g}")
        print(f"g_residual/(RT) = {result.g_residual_rt:.12g}")
    print("\nFeed-property diagnostics alone do not determine phase stability or vapor fraction.")
    print("These results are feed-property diagnostics, not a flash result.")



def print_stability_search(mixture, conditions, *, kij):
    """Display local search outcome, convergence and negative witness."""
    result = search_pr_stability(mixture, conditions, kij=kij)
    print("\nMULTI-START TPD SEARCH (PR1976):")
    print("Status:", result.status)
    print("Reference Z:", result.reference_z)
    print("TPD sign tolerance:", result.tpd_tolerance)
    print("Smallest evaluated TPD:", result.minimum_tpd)
    if result.witness_composition is not None:
        print("Composition at smallest evaluated TPD:")
        for c, value in zip(mixture.components, result.witness_composition):
            print(f"  {c.name}: {value:.10g}")
    print(f"{'Start':<30} {'Converged':>10} {'Iters':>7} {'Minimum TPD':>16}")
    for record in result.starts:
        value = 'not evaluated' if record.minimum_tpd is None else f'{record.minimum_tpd:.8g}'
        print(f"{record.label:<30} {str(record.converged):>10} {record.iterations:>7} {value:>16}")
        print("  Stationarity residual:", record.stationarity_residual)
        if not record.converged:
            print("  Reason:", record.reason)
    if result.status == 'unstable':
        print("A negative TPD witness was found: the selected feed reference is unstable.")
    elif result.status == 'no_negative_tpd_found':
        print("All starts converged and no negative TPD witness was found.")
        print("This local search does not certify global phase stability.")
    else:
        print("INCONCLUSIVE: search failures or ambiguous reference roots prevent a conclusion.")
    print("No equilibrium phase compositions or vapor fraction have been calculated.")



def print_flash(mixture, conditions, *, kij):
    """Display only validated phase split fields; incomplete results remain absent."""
    result = flash_tp(mixture, conditions, kij=kij)
    print("\nTP FLASH (PR1976, simple-hydrocarbon VLE scope):")
    print("Status:", result.status)
    print(result.message)
    print("Feed stability search:", result.feed_stability.status)
    print("Smallest feed TPD:", result.feed_stability.minimum_tpd)
    if result.status == 'two_phase':
        print(f"Vapor mole fraction beta: {result.beta:.12g}")
        print(f"Liquid mole fraction: {1-result.beta:.12g}")
        print(f"Z_liquid: {result.liquid_z:.12g}; Z_vapor: {result.vapor_z:.12g}")
        print(f"{'Component':<20} {'Feed z':>14} {'Liquid x':>14} {'Vapor y':>14}")
        for component, z, x, y in zip(mixture.components, mixture.mole_fractions,
                                      result.liquid_composition, result.vapor_composition):
            print(f"{component.name:<20} {z:14.9g} {x:14.9g} {y:14.9g}")
        print("Iterations in successful attempt:", result.iterations)
        print("Max |ln(f_liquid/f_vapor)|:", result.fugacity_residual)
        print("Max component material-balance residual:", result.material_residual)
        print("Max phase-normalization residual:", result.normalization_residual)
        print("Gibbs change/(RT) relative to feed:", result.gibbs_change_rt)
        print("Local post-flash phase searches:", tuple(s.status for s in result.phase_stability))
        print("Local checks passed; global phase stability and experimental accuracy are not certified.")
    elif result.status == 'single_phase_candidate':
        print("Reference Z:", result.feed_stability.reference_z)
        print("No split was found by the local search. No liquid/vapor label or beta is assigned.")
    else:
        print("No accepted phase compositions or vapor fraction are available.")
    if result.attempts:
        print("Unsuccessful attempts:")
        for reason in result.attempts:
            print("  ", reason)
    return result


def main():
    parser = argparse.ArgumentParser(
        description="Read PetroFlash feed/TP inputs and optionally calculate PR feed properties."
    )
    parser.add_argument("--database", default="data/components.json",
                        help="Path to the component JSON database.")
    parser.add_argument("--pr", action="store_true",
                        help="Calculate PR1976 feed properties after explicit zero-kij confirmation.")
    parser.add_argument("--stability", action="store_true",
                        help="Run multi-start TPD search; includes PR diagnostics and zero-kij confirmation.")
    parser.add_argument("--flash", action="store_true",
                        help="Run baseline hydrocarbon TP flash with pre/post local stability checks.")
    args = parser.parse_args()
    try:
        database = ComponentDatabase.from_file(args.database)
    except (OSError, TypeError, ValueError, KeyError) as error:
        parser.exit(1, f"Database error: {error}\n")
    try:
        mixture = read_mixture(database)
        conditions = read_conditions()
    except (EOFError, KeyboardInterrupt):
        print("\nInput cancelled.")
        return

    print("\nValidated overall feed composition:")
    print(f"{'Component':<20} {'Mole %':>12} {'Mole fraction':>16}")
    for component, percentage, fraction in zip(
        mixture.components, mixture.mole_percentages, mixture.mole_fractions
    ):
        print(f"{component.name:<20} {percentage:>12.6f} {fraction:>16.8f}")
    print(f"\nTemperature: {conditions.temperature_k:.8g} K")
    print(f"Absolute pressure: {conditions.pressure_pa:.8g} Pa")
    if not (args.pr or args.stability or args.flash):
        print("Feed and TP conditions are ready. Use --pr, --stability or --flash to calculate.")
        return
    try:
        if not confirm_zero_kij():
            print("PR calculation skipped. Supply validated interactions through the Python API.")
            return
        print("Model assumption for this run: ALL kij = 0; not validated pair data.")
        kij = zero_kij(len(mixture.components))
        if args.flash:
            result = print_flash(mixture, conditions, kij=kij)
            if result.status == "inconclusive":
                parser.exit(1, "Flash result is inconclusive; no phase split accepted.\n")
        else:
            print_pr_feed(mixture, conditions, kij=kij)
            if args.stability:
                print_stability_search(mixture, conditions, kij=kij)
    except (EOFError, KeyboardInterrupt):
        print("\nInput cancelled.")
    except (TypeError, ValueError, ArithmeticError) as error:
        parser.exit(1, f"PR calculation error: {error}\n")


if __name__ == "__main__":
    main()
