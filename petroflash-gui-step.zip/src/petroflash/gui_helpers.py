"""Presentation helpers shared by the PetroFlash desktop interface and tests."""

from __future__ import annotations


PROPERTY_FIELDS = (
    ("critical_temperature", "دمای بحرانی"),
    ("critical_pressure", "فشار بحرانی"),
    ("acentric_factor", "ضریب بی‌مرکزی"),
    ("molar_mass", "جرم مولی"),
)


def component_property_rows(component):
    """Return every stored EOS property and its provenance for a component."""
    rows = []
    for field, label in PROPERTY_FIELDS:
        record = getattr(component, field)
        rows.append({
            "component": component.name,
            "property": label,
            "value": format(record.value, ".12g"),
            "unit": record.unit,
            "source": record.source,
            "method": record.method,
            "data_kind": getattr(record.data_kind, "value", record.data_kind),
            "uncertainty": ("نامشخص" if record.uncertainty is None
                            else format(record.uncertainty, ".8g")),
            "reference": record.reference,
            "notes": record.notes,
        })
    return tuple(rows)


def format_flash_result(result, mixture, conditions=None):
    """Format only fields that the flash engine actually accepted."""
    lines = ["نتیجهٔ فلش PR1976"]
    if conditions is not None:
        lines.extend((
            f"دما: {conditions.temperature_k:.10g} K",
            f"فشار مطلق: {conditions.pressure_pa:.10g} Pa",
        ))
    lines.append("خوراک: " + ", ".join(
        f"{name}={percent:.8g} mol%"
        for name, percent in zip(mixture.names, mixture.mole_percentages)
    ))
    lines.append(f"وضعیت: {result.status}")
    lines.append(result.message)
    stability = getattr(result, "feed_stability", None)
    if stability is not None:
        lines.append(f"جست‌وجوی پایداری خوراک: {stability.status}")
        minimum = getattr(stability, "minimum_tpd", None)
        if minimum is not None:
            lines.append(f"کمترین TPD ارزیابی‌شده: {minimum:.10g}")

    if result.status == "two_phase":
        required = (result.beta, result.liquid_composition,
                    result.vapor_composition, result.liquid_z, result.vapor_z)
        if any(value is None for value in required):
            lines.append("خروجی ناقص است؛ کسر فاز و ترکیب فازها نمایش داده نمی‌شود.")
            return "\n".join(lines)
        lines.extend((
            f"کسر مولی بخار، beta: {result.beta:.12g}",
            f"کسر مولی مایع: {1.0-result.beta:.12g}",
            f"Z مایع: {result.liquid_z:.12g}",
            f"Z بخار: {result.vapor_z:.12g}",
            "",
            "ترکیب‌ها (کسر مولی):",
        ))
        for name, z, x, y in zip(
            mixture.names, mixture.mole_fractions,
            result.liquid_composition, result.vapor_composition,
        ):
            lines.append(f"{name}: خوراک z={z:.10g} | مایع x={x:.10g} | بخار y={y:.10g}")
        for label, value in (
            ("باقی‌ماندهٔ لگاریتمی فوگاسیته", result.fugacity_residual),
            ("باقی‌ماندهٔ موازنهٔ ماده", result.material_residual),
            ("باقی‌ماندهٔ نرمال‌سازی", result.normalization_residual),
            ("تغییر گیبس/(RT)", result.gibbs_change_rt),
            ("برآورد تفکیک‌پذیری گیبس/(RT)", getattr(result, "gibbs_resolution_rt", None)),
        ):
            if value is not None:
                lines.append(f"{label}: {value:.10g}")
        lines.append(f"تکرارها در تلاش پذیرفته‌شده: {result.iterations}")
        phase_checks = getattr(result, "phase_stability", ())
        if phase_checks:
            lines.append("جست‌وجوی محلی پس از فلش: " + ", ".join(q.status for q in phase_checks))
        lines.append("این کنترل‌های محلی، پایداری سراسری یا اعتبار تجربی را اثبات نمی‌کنند.")
    elif result.status == "single_phase_candidate":
        lines.append("کسر بخار یا برچسب مایع/بخار از این نتیجه تعیین نشده است.")
    else:
        lines.append("جواب تقسیم فازی پذیرفته‌شده‌ای در دسترس نیست.")
        for attempt in getattr(result, "attempts", ()):
            lines.append(f"- {attempt}")
    return "\n".join(lines)
